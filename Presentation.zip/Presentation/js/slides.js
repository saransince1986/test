var slides=[
    {
        bg:'images/slide1.png',
        content:'<div class="title centerTitle">PEARSON VISIT</div><div class="slideContent"><div id="presentationDate">18<sup>TH</sup> JANUARY 2017</div></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">LAPIZ TEAM INTRODUCTION</div><div class="slideContent"><iframe style="border:none; overflow:hidden;" width="800" height="365" src="animation_pages/slide2/index.html"></iframe></div>'
    },
    {
        bg:'images/slide2.png',
        content:'<div class="slideContent"><iframe style="border:none; overflow:hidden;" width="800" height="365" src="animation_pages/slide3/index.html"></iframe><div class="title botHeading">Thirumalai Chemicals Ltd</div><div class="contact1"><b>Unit 1</b><br/>25-A Sipcot Industrial Complex<br/>Ranipet - 632 403, Tamil Nadu, India</div><div class="contact2"><b>Unit 2</b><br/>Kemaman<br/>Terengganu State of Malaysia.</div></div>'
    },
    {
        bg:'images/slide2.png',
        content:'<div class="slideContent"><iframe style="border:none; overflow:hidden;" width="800" height="365" src="animation_pages/slide4/index.html"></iframe><div class="title botHeading">Ultramarine &amp; Pigments Ltd</div><div class="contact1"><b>Unit 1</b><br/>556, Vanagaram Road, Ambattur,<br/>Chennai, Tamil Nadu 600053</div><div class="contact2"><b>Unit 2</b><br/>25-B Sipcot Industrial Complex,<br/>Ranipet - 632 403, Tamil Nadu, India</div><div class="botGallery"><img src="images/upl.png"/></div></div>'
    },
    {
        bg:'images/slide2.png',
        content:'<div class="slideContent"><iframe style="border:none; overflow:hidden;" width="800" height="365" src="animation_pages/slide4/index.html"></iframe><div class="title botHeading">Ultramarine &amp; Pigments Ltd</div><div class="contact1"><b>Unit 1</b><br/>556, Vanagaram Road, Ambattur,<br/>Chennai, Tamil Nadu 600053</div><div class="contact2"><b>Unit 2</b><br/>25-B Sipcot Industrial Complex,<br/>Ranipet - 632 403, Tamil Nadu, India</div><div class="botGallery"><img src="images/upl.png"/></div></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">LAPIZ DIGITAL SERVICES - LOCATIONS</div><div class="slideContent"></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">GROUP FINANCIALS</div><div class="slideContent"><div id="slide7Graphcontainer" style="min-width: 310px; height: 400px; margin: 0 auto"></div></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">LAPIZ DIGITAL SERVICES FINANCIALS</div><div class="slideContent"><div id="slide8Graphcontainer" style="min-width: 310px; height: 400px; margin: 0 auto"></div></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">LAPIZ DIGITAL SERVICES - SEATS</div><div class="slideContent"><div id="slide9Graphcontainer" style="min-width: 310px; height: 400px; margin: 0 auto"></div></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">SERVICES FOR PEARSON</div><div class="slideContent"></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">SERVICES FOR PEARSON</div><div class="slideContent"></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">PEARSON APPROXIMATE SPENT YOY IN US$</div><div class="slideContent"><div class="slide12TblCon"><table cellpadding="5" cellspacing="0"><tr><td><b>Year - 2013-14</b></td><td><b>USD</b></td></tr><tr><td>PRE-PRESS</td><td>1,134</td></tr><tr><td>CONVERSION</td><td>36,266</td></tr><tr><td>DIGITAL</td><td>1,00,369</td></tr><tr><td><b>Year - 2014-15</b></td><td></td></tr><tr><td>PRE-PRESS</td><td>411</td></tr><tr><td>CONVERSION</td><td>18,177</td></tr><tr><td>DIGITAL</td><td>5,94,817</td></tr><tr><td><b>Year - 2015-16</b></td><td></td></tr><tr><td>PRE-PRESS</td><td>214</td></tr><tr><td>CONVERSION</td><td>6,723</td></tr><tr><td>DIGITAL</td><td>4,70,469</td></tr></table></div><div class="slide12TblCon2"><table cellpadding="5" cellspacing="0"><tr><td><b>Year - 2016-17</b></td><td><b>USD</b></td></tr><tr><td>PRE-PRESS</td><td>65</td></tr><tr><td>CONVERSION</td><td>8,753</td></tr><tr><td>DIGITAL</td><td>-</td></tr></table></div></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">LAPIZ CORE OFFERINGS</div><div class="slideContent"><div class="oval Lapiz">Lapiz</div><div class="oval software">Software</div><div class="oval helpdesk">Helpdesk</div><div class="oval publishing">Publishing</div><div class="oval healthcare">US Healthcare</div></div>'
    },
    {
        bg:'images/slide2.png',
        content: '<div class="title topHeading">PUBLISHING</div><div class="slideContent"><div class="printImg"><img src="images/publishing.png" width="500"/></div></div>'
    },
]