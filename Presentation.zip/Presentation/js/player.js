var currentSlide = 13;
var totSlides = slides.length;
var isFullScreen = false;

if (totSlides<=0) {
    totSlides = 1;
}
var bodyWidth = $('body').width();
var bodyHeight = $('body').height();

var playerWidth = $('#player').width();
var playerHeight = $('#player').height();

var playerLeft = (bodyWidth - playerWidth) / 2;
var playerTop = (bodyHeight - playerHeight) / 2;

$('#player').css({'left':playerLeft+'px','top':playerTop+'px'});
var playerDetails = {
    left: $('#player').position().left,
    top: $('#player').position().top,
    width: $('#player').width(),
    height: $('#player').height()
}
loadSlide();

$('#prevBtn').click(function(){
    currentSlide--;
    $('#nextBtn').removeClass('disabled');  
    loadSlide();
});

$('#nextBtn').click(function(){
    currentSlide++;
    $('#prevBtn').removeClass('disabled');
    loadSlide();
});

$('#fullscreenBtn').click(function(){
    toggleFullScreen();
});
function loadSlide(){
    $('#playerView').fadeOut(function(){
    $('#playerView').css({'background-image':'url("'+slides[currentSlide-1].bg+'")'});
    $('#playerView').html("<div class='slide"+currentSlide+"'>"+slides[currentSlide-1].content+"</div>");
    $('#curSlide').text(currentSlide);
    $('#totSlides').text(totSlides);
    if (currentSlide>=totSlides) {
        $('#nextBtn').addClass('disabled');
    }
    if (currentSlide<=1) {
        $('#prevBtn').addClass('disabled');
    }
    $('#playerView').fadeIn();
    });
 callback();   
}

function toggleFullScreen() {
    if (isFullScreen == false)
    {
        if("fullscreenEnabled" in document || "webkitFullscreenEnabled" in document || "mozFullScreenEnabled" in document || "msFullscreenEnabled" in document) 
        {
            if(document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled)
            {
                  var element = document.getElementById("player");
                  if("requestFullscreen" in element) 
                  {
                      element.requestFullscreen();
                      isFullScreen = true;
                  } 
                  else if ("webkitRequestFullscreen" in element) 
                  {
                      element.webkitRequestFullscreen();
                      isFullScreen = true;
                  } 
                  else if ("mozRequestFullScreen" in element) 
                  {
                      element.mozRequestFullScreen();
                      isFullScreen = true;
                  } 
                  else if ("msRequestFullscreen" in element) 
                  {
                      element.msRequestFullscreen();
                      isFullScreen = true;
                  }
          
              }
        }
    }
    else {
        if(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement) 
        {
            if ("exitFullscreen" in document) 
            {
                document.exitFullscreen();
                isFullScreen = false;
            } 
            else if ("webkitExitFullscreen" in document) 
            {
                document.webkitExitFullscreen();
                isFullScreen = false;
            } 
            else if ("mozCancelFullScreen" in document) 
            {
                document.mozCancelFullScreen();
                isFullScreen = false;
            } 
            else if ("msExitFullscreen" in document) 
            {
                document.msExitFullscreen();
                isFullScreen = false;
            }
        }
        
    }
    
    $('#player').css({'left':playerDetails.left+'px','top':playerDetails.top+'px'});
    setTimeout(function(){
    if (isFullScreen) {
        var scaleWidth = $(window).width()/$('#player').width();
        var scaleHeight = ($(window).height())/$('#player').height();
        var scale = Math.min(scaleWidth, scaleHeight);
        
        var calcLeft = ($(window).width()-(scale*$('#player').width()))/2;
        var calcTop = ($(window).height()-(scale*$('#player').height()))/2;
        console.log("calcLeft", $(window).width(),(scale*$('#player').width()));
        
        $('#player').css({'transform':'scale('+scale+')','left':calcLeft+'px','top':calcTop+'px'});
        
    }
    else {
        console.log("playerDetails", playerDetails);
        $('#player').css({'transform':'scale(1)','left':playerDetails.left+'px','top':playerDetails.top+'px'});
    }
    },100);
}

function callback()
{
  if(currentSlide==2)
  {
    $("#sb-container").swatchbook();
  }
  else if(currentSlide==7)
  {
    setTimeout(function(){
    Highcharts.chart('slide7Graphcontainer', {
        chart: {
            type: 'column',
            width:600,
            height:350
        },
        title: {
            text: 'Ultramarine & Pigments'
        },
        xAxis: {
            categories: ['2014', '2015', '2015']
        },
        yAxis: {
            min: 0,
            title: {
                text: 'INR'
            },
            stackLabels: {
                enabled: true,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                }
            }
        },
        legend: {
            align: 'right',
            x: -30,
            verticalAlign: 'top',
            y: 25,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            borderColor: '#CCC',
            borderWidth: 1,
            shadow: false
        },
        
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: true,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            }
        },
        series: [{
            name: 'Revenue',
            data: [22877346, 25953236, 33615174]
        }, {
            name: 'Profitability in %',
            data: [9, 11, 12]
        }, {
            name: 'Liquidity',
            data: [9408819, 11508529, 11196169]
        }]
    });
 
  },1000);

  }
  else if(currentSlide==8)
  {
    setTimeout(function(){
    Highcharts.chart('slide8Graphcontainer', {
        chart: {
            type: 'column',
            width:600,
            height:350
        },
        title: {
            text: 'EBITA %'
        },
        xAxis: {
            categories: ['2013-14', '2014-15', '2015-16']
        },
        yAxis: {
            min: 0,
            title: {
                text: '%'
            },
            stackLabels: {
                enabled: true,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                }
            }
        },
        legend: {
            align: 'right',
            x: -30,
            verticalAlign: 'top',
            y: 25,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            borderColor: '#CCC',
            borderWidth: 1,
            shadow: false
        },
        
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: true,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            }
        },
        series: [{
            name: 'EBITA',
            data: [30, 30, 29]
        }]
    });
 
  },1000);

  }
  else if(currentSlide==9)
  {
    setTimeout(function(){
    Highcharts.chart('slide9Graphcontainer', {
        chart: {
            type: 'column',
            width:600,
            height:350
        },
        title: {
            text: 'Lapiz'
        },
        xAxis: {
            categories: ['Chennai', 'Ranipet', 'Ranipet','Trichy','Trichy**']
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Seats'
            },
            stackLabels: {
                enabled: true,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                }
            }
        },
        legend: {
            align: 'right',
            x: -30,
            verticalAlign: 'top',
            y: 25,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
            borderColor: '#CCC',
            borderWidth: 1,
            shadow: false
        },
        
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: true,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            }
        },
        series: [{
            name: 'Seats',
            data: [235, 150, 94, 30,150]
        }]
    });
 
  },1000);

  }
  else if(currentSlide==13)
  {
    setTimeout(function(){
      $(".oval").each(function(index) {
          $(this).delay(1000*index).fadeIn('slow');
      });
    },500);
    
  }
  else if(currentSlide==14)
  {
    setTimeout(function(){
      $(".printImg img").addClass('imgRotate');
    },500);
    
  }
}